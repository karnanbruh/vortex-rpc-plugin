@echo off
pushd "C:\Program Files\Microsoft Visual Studio\18\Insiders\VC\Auxiliary\Build\"
call vcvarsall.bat x86
popd
cd /d "c:\Users\Biravin A\Downloads\historic-rpc-plugin\historic-rpc-plugin"
call compile.bat
