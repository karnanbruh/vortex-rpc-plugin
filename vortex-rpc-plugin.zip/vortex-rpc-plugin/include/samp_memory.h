#pragma once
#include <windows.h>
#include <string>
#include <cstdint>

// SA-MP client memory offsets (SA-MP 0.3.7 R1/R2/R3)
namespace SAMP {

    // Base address of samp.dll
    inline uintptr_t GetSAMPBase() {
        static uintptr_t base = 0;
        if (!base) {
            base = (uintptr_t)GetModuleHandleA("samp.dll");
        }
        return base;
    }

    // Check if SA-MP is loaded
    inline bool IsLoaded() {
        return GetSAMPBase() != 0;
    }

    // SA-MP version detection
    enum class Version {
        UNKNOWN,
        V037_R1,
        V037_R2,
        V037_R3_1,
    };

    inline Version GetVersion() {
        uintptr_t base = GetSAMPBase();
        if (!base) return Version::UNKNOWN;
        // Check specific offsets to determine version
        uint8_t* check = (uint8_t*)(base + 0x128);
        if (*check == 0x50) return Version::V037_R1;
        if (*check == 0xC3) return Version::V037_R2;
        return Version::V037_R3_1;
    }

    // Offsets for samp.dll (0.3.7 R1)
    namespace Offsets_R1 {
        constexpr uintptr_t SAMP_INFO         = 0x21A0F8;
        constexpr uintptr_t LOCALPLAYER_NAME  = 0x219A90;
        constexpr uintptr_t LOCALPLAYER_ID    = 0x21A0AC;
        constexpr uintptr_t SERVER_IP         = 0x219A4C;
        constexpr uintptr_t SERVER_PORT       = 0x21A0B4;
        constexpr uintptr_t SERVER_NAME       = 0x219A58;
        constexpr uintptr_t PLAYER_SCORE      = 0x21A0B0;
        constexpr uintptr_t PLAYERS_COUNT     = 0x219AEC;
        constexpr uintptr_t MAX_PLAYERS       = 0x219AD4;
    }

    // Offsets for samp.dll (0.3.7 R2)
    namespace Offsets_R2 {
        constexpr uintptr_t SAMP_INFO         = 0x21A100;
        constexpr uintptr_t LOCALPLAYER_NAME  = 0x219A98;
        constexpr uintptr_t LOCALPLAYER_ID    = 0x21A0B4;
        constexpr uintptr_t SERVER_IP         = 0x219A54;
        constexpr uintptr_t SERVER_PORT       = 0x21A0BC;
        constexpr uintptr_t SERVER_NAME       = 0x219A60;
        constexpr uintptr_t PLAYER_SCORE      = 0x21A0B8;
        constexpr uintptr_t PLAYERS_COUNT     = 0x219AF4;
        constexpr uintptr_t MAX_PLAYERS       = 0x219ADC;
    }

    // Offsets for samp.dll (0.3.7 R3-1)
    namespace Offsets_R3 {
        constexpr uintptr_t SAMP_INFO         = 0x26E8DC;
        constexpr uintptr_t LOCALPLAYER_NAME  = 0x26E204;
        constexpr uintptr_t LOCALPLAYER_ID    = 0x26E8A0;
        constexpr uintptr_t SERVER_IP         = 0x26E210;
        constexpr uintptr_t SERVER_PORT       = 0x26E8A8;
        constexpr uintptr_t SERVER_NAME       = 0x26E21C;
        constexpr uintptr_t PLAYER_SCORE      = 0x26E8A4;
        constexpr uintptr_t PLAYERS_COUNT     = 0x26E2D8;
        constexpr uintptr_t MAX_PLAYERS       = 0x26E2C0;
    }

    inline uintptr_t GetOffset(uintptr_t r1, uintptr_t r2, uintptr_t r3) {
        switch (GetVersion()) {
            case Version::V037_R1:   return r1;
            case Version::V037_R2:   return r2;
            case Version::V037_R3_1: return r3;
            default:                 return r3; // fallback to R3
        }
    }

    inline std::string ReadString(uintptr_t addr, size_t maxLen = 256) {
        if (!addr) return "";
        char buf[256] = {};
        size_t len = min(maxLen, sizeof(buf) - 1);
        __try {
            strncpy_s(buf, (const char*)addr, len);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return "";
        }
        return std::string(buf);
    }

    inline std::string GetPlayerName() {
        uintptr_t base = GetSAMPBase();
        if (!base) return "Unknown";
        uintptr_t off = GetOffset(
            Offsets_R1::LOCALPLAYER_NAME,
            Offsets_R2::LOCALPLAYER_NAME,
            Offsets_R3::LOCALPLAYER_NAME
        );
        return ReadString(base + off);
    }

    inline std::string GetServerName() {
        uintptr_t base = GetSAMPBase();
        if (!base) return "";
        uintptr_t off = GetOffset(
            Offsets_R1::SERVER_NAME,
            Offsets_R2::SERVER_NAME,
            Offsets_R3::SERVER_NAME
        );
        return ReadString(base + off);
    }

    inline std::string GetServerIP() {
        uintptr_t base = GetSAMPBase();
        if (!base) return "";
        uintptr_t off = GetOffset(
            Offsets_R1::SERVER_IP,
            Offsets_R2::SERVER_IP,
            Offsets_R3::SERVER_IP
        );
        return ReadString(base + off, 64);
    }

    inline int GetServerPort() {
        uintptr_t base = GetSAMPBase();
        if (!base) return 0;
        uintptr_t off = GetOffset(
            Offsets_R1::SERVER_PORT,
            Offsets_R2::SERVER_PORT,
            Offsets_R3::SERVER_PORT
        );
        __try {
            return *(int*)(base + off);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return 0;
        }
    }

    inline int GetPlayerScore() {
        uintptr_t base = GetSAMPBase();
        if (!base) return 0;
        uintptr_t off = GetOffset(
            Offsets_R1::PLAYER_SCORE,
            Offsets_R2::PLAYER_SCORE,
            Offsets_R3::PLAYER_SCORE
        );
        __try {
            return *(int*)(base + off);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return 0;
        }
    }

    inline int GetPlayersCount() {
        uintptr_t base = GetSAMPBase();
        if (!base) return 0;
        uintptr_t off = GetOffset(
            Offsets_R1::PLAYERS_COUNT,
            Offsets_R2::PLAYERS_COUNT,
            Offsets_R3::PLAYERS_COUNT
        );
        __try {
            return *(int*)(base + off);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return 0;
        }
    }

    inline int GetMaxPlayers() {
        uintptr_t base = GetSAMPBase();
        if (!base) return 0;
        uintptr_t off = GetOffset(
            Offsets_R1::MAX_PLAYERS,
            Offsets_R2::MAX_PLAYERS,
            Offsets_R3::MAX_PLAYERS
        );
        __try {
            return *(int*)(base + off);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return 0;
        }
    }

    inline bool IsInServer() {
        uintptr_t base = GetSAMPBase();
        if (!base) return false;
        uintptr_t off = GetOffset(
            Offsets_R1::SAMP_INFO,
            Offsets_R2::SAMP_INFO,
            Offsets_R3::SAMP_INFO
        );
        __try {
            uintptr_t info = *(uintptr_t*)(base + off);
            return info != 0;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }

} // namespace SAMP
