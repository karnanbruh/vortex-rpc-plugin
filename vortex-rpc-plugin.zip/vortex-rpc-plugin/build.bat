@echo off
REM Historic RPC Build Script
REM Automatically locates Visual Studio 2022 and builds the ASI plugin

setlocal enabledelayedexpansion

REM Try to find vcvars32.bat
set "VCVARS="
for /f "tokens=*" %%A in ('dir /s /b vcvars32.bat 2^>nul ^| findstr /R ".*VC.*"') do (
    set "VCVARS=%%A"
    goto :found_vcvars
)

:found_vcvars
if not defined VCVARS (
    echo Error: Could not find Visual Studio vcvars32.bat
    exit /b 1
)

echo Found vcvars at: !VCVARS!

REM Call vcvars to set up the environment
call "!VCVARS!"

REM Create build directory
if not exist build mkdir build
cd /d build

REM Run CMake
echo Configuring CMake...
cmake .. -A Win32
if errorlevel 1 (
    echo CMake configuration failed
    exit /b 1
)

REM Build
echo Building...
cmake --build . --config Release
if errorlevel 1 (
    echo Build failed
    exit /b 1
)

echo Build successful!
echo ASI plugin: %cd%\Release\HistoricRPC.asi
endlocal
