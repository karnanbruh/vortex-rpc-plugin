//
// VORTEX ROLE PLAY - SA-MP Discord Rich Presence Plugin
// ASI Plugin for GTA San Andreas + SA-MP
//
// Discord Application: https://discord.com/developers/applications
// Place discord_game_sdk.dll (or discord-rpc.dll) next to gta_sa.exe
//

#define _WINSOCK_DEPRECATED_NO_WARNINGS
#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include <string>
#include <sstream>
#include <ctime>
#include <thread>
#include <atomic>
#include <cctype>
#include <cstdlib>

#include "discord_rpc.h"
#include "samp_memory.h"

// ─── CONFIG ──────────────────────────────────────────────────────────────────
// Replace this with your Discord Application ID from:
// https://discord.com/developers/applications
// Set "Large Image Key" to "historic_logo" after uploading the logo in Art Assets
static const char* DISCORD_APP_ID    = "YOUR_VORTEX_DISCORD_APPLICATION_ID";

// Server info shown in presence
static const char* SERVER_NAME_LABEL = "VORTEX ROLE PLAY";
static const char* SERVER_SUBTITLE   = "GTA San Andreas Multiplayer";
static const char* SERVER_IP         = "vxrplaunchsoon:7777";  // VORTEX ROLE PLAY server address
static const char* DISCORD_INVITE    = "https://discord.gg/xW5ZzD5ajq";
static const char* LARGE_IMAGE_KEY   = "vortex_logo";                 // upload VORTEX logo with this exact key
static const char* LARGE_IMAGE_TEXT  = "VORTEX ROLE PLAY | Join our Discord";
static const char* SMALL_IMAGE_KEY   = "samp_icon";                  // optional second image
static const char* SMALL_IMAGE_TEXT  = "Playing GTA San Andreas Multiplayer";
static const int DEFAULT_MAX_PLAYERS = 100;

// How often (ms) to refresh the presence
static const DWORD UPDATE_INTERVAL_MS = 5000;
// ─────────────────────────────────────────────────────────────────────────────

static std::atomic<bool> g_running(false);
static int64_t g_startTimestamp = 0;
static bool g_winsockReady = false;

struct ServerAddress {
    std::string host;
    int port;
};

struct ServerStats {
    int players;
    int maxPlayers;
    std::string name;
};

static bool SplitServerAddress(const std::string& address, ServerAddress& out) {
    size_t colon = address.rfind(':');
    if (colon == std::string::npos) {
        out.host = address;
        out.port = 7777; // Default SA-MP port
        return !out.host.empty();
    }

    if (colon + 1 >= address.length()) return false;

    std::string host = address.substr(0, colon);
    std::string portStr = address.substr(colon + 1);
    int port = std::atoi(portStr.c_str());
    if (host.empty() || port <= 0 || port > 65535) return false;

    out.host = host;
    out.port = port;
    return true;
}

static std::string ExtractCommandLineValue(const char* key) {
    const char* rawCmd = GetCommandLineA();
    if (!rawCmd || !key) return "";

    std::string cmd(rawCmd);
    std::string marker(key);
    size_t pos = cmd.find(marker);
    if (pos == std::string::npos) return "";

    pos += marker.length();
    while (pos < cmd.length() && cmd[pos] == ' ') ++pos;
    if (pos >= cmd.length()) return "";

    char quote = 0;
    if (cmd[pos] == '"' || cmd[pos] == '\'') {
        quote = cmd[pos++];
    }

    size_t end = pos;
    while (end < cmd.length()) {
        if (quote) {
            if (cmd[end] == quote) break;
        } else if (cmd[end] == ' ') {
            break;
        }
        ++end;
    }

    return cmd.substr(pos, end - pos);
}

static std::string CleanPresenceText(const std::string& text, const char* fallback) {
    std::string clean;
    clean.reserve(text.size());

    for (size_t i = 0; i < text.size(); ++i) {
        unsigned char ch = static_cast<unsigned char>(text[i]);

        if (ch == '{' && i + 7 < text.size()) {
            bool colorCode = text[i + 7] == '}';
            for (size_t j = i + 1; colorCode && j < i + 7; ++j) {
                colorCode = std::isxdigit(static_cast<unsigned char>(text[j])) != 0;
            }
            if (colorCode) {
                i += 7;
                continue;
            }
        }

        if ((ch >= 'A' && ch <= 'Z') ||
            (ch >= 'a' && ch <= 'z') ||
            (ch >= '0' && ch <= '9') ||
            ch == '_' || ch == '[' || ch == ']' || ch == '(' || ch == ')' ||
            ch == '-' || ch == '.' || ch == ' ' || ch == ':' || ch == '|') {
            clean.push_back(static_cast<char>(ch));
        }
    }

    while (!clean.empty() && clean.front() == ' ') clean.erase(clean.begin());
    while (!clean.empty() && clean.back() == ' ') clean.pop_back();

    int lettersOrDigits = 0;
    for (size_t i = 0; i < clean.length(); ++i) {
        if (std::isalnum(static_cast<unsigned char>(clean[i]))) {
            ++lettersOrDigits;
        }
    }

    return lettersOrDigits < 2 ? fallback : clean;
}

static std::string GetBestPlayerName() {
    std::string fromCmd = CleanPresenceText(ExtractCommandLineValue("-n"), "");
    if (!fromCmd.empty()) return fromCmd;

    fromCmd = CleanPresenceText(ExtractCommandLineValue("/name"), "");
    if (!fromCmd.empty()) return fromCmd;

    return CleanPresenceText(SAMP::GetPlayerName(), "Unknown");
}

static std::string GetBestServerAddress() {
    std::string fromMemory = CleanPresenceText(SAMP::GetServerIP(), "");
    int portFromMemory = SAMP::GetServerPort();
    if (!fromMemory.empty() && portFromMemory > 0 && portFromMemory <= 65535) {
        std::ostringstream ss;
        ss << fromMemory << ":" << portFromMemory;
        return ss.str();
    }

    std::string host = CleanPresenceText(ExtractCommandLineValue("-h"), "");
    std::string port = CleanPresenceText(ExtractCommandLineValue("-p"), "");

    if (!host.empty()) {
        return port.empty() ? host : host + ":" + port;
    }

    return SERVER_IP;
}

static int ClampMaxPlayers(int maxPlayers) {
    if (maxPlayers >= 1 && maxPlayers <= 1000) return maxPlayers;
    return DEFAULT_MAX_PLAYERS;
}

static int ClampPlayersCount(int playersCount, int maxPlayers) {
    if (playersCount >= 0 && playersCount <= maxPlayers) return playersCount;
    return 0;
}

static bool QuerySampServerStats(const std::string& address, ServerStats& stats) {
    if (!g_winsockReady) return false;

    ServerAddress parsed = {};
    if (!SplitServerAddress(address, parsed)) {
        return false;
    }

    // Try to resolve hostname if it's not an IP
    unsigned long ip = inet_addr(parsed.host.c_str());
    if (ip == INADDR_NONE) {
        hostent* he = gethostbyname(parsed.host.c_str());
        if (!he) return false;
        ip = *(unsigned long*)he->h_addr_list[0];
    }

    SOCKET sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sock == INVALID_SOCKET) return false;

    // Set a reasonable timeout for the query
#ifdef _WIN32
    DWORD timeoutMs = 1000;
#else
    struct timeval timeoutMs = {1, 0};
#endif
    setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, (const char*)&timeoutMs, sizeof(timeoutMs));

    sockaddr_in target = {};
    target.sin_family = AF_INET;
    target.sin_port = htons((u_short)parsed.port);
    target.sin_addr.S_un.S_addr = ip;

    unsigned char* ipBytes = (unsigned char*)&ip;
    char packet[11] = {
        'S', 'A', 'M', 'P',
        (char)ipBytes[0], (char)ipBytes[1], (char)ipBytes[2], (char)ipBytes[3],
        (char)(parsed.port & 0xff), (char)((parsed.port >> 8) & 0xff),
        'i'
    };

    int sent = sendto(sock, packet, sizeof(packet), 0, (const sockaddr*)&target, sizeof(target));
    if (sent == SOCKET_ERROR) {
        closesocket(sock);
        return false;
    }

    char response[512] = {};
    int fromLen = sizeof(target);
    int received = recvfrom(sock, response, sizeof(response), 0, (sockaddr*)&target, &fromLen);
    closesocket(sock);

    if (received < 16) return false;
    if (response[0] != 'S' || response[1] != 'A' || response[2] != 'M' || response[3] != 'P' || response[10] != 'i') {
        return false;
    }

    unsigned char lowPlayers = (unsigned char)response[12];
    unsigned char highPlayers = (unsigned char)response[13];
    unsigned char lowMax = (unsigned char)response[14];
    unsigned char highMax = (unsigned char)response[15];
    int players = lowPlayers | (highPlayers << 8);
    int maxPlayers = lowMax | (highMax << 8);

    if (maxPlayers <= 0 || maxPlayers > 1000 || players < 0 || players > maxPlayers) return false;

    stats.players = players;
    stats.maxPlayers = maxPlayers;

    if (received >= 20) {
        unsigned char b0 = (unsigned char)response[16];
        unsigned char b1 = (unsigned char)response[17];
        unsigned char b2 = (unsigned char)response[18];
        unsigned char b3 = (unsigned char)response[19];
        int nameLen = b0 | (b1 << 8) | (b2 << 16) | (b3 << 24);
        if (nameLen > 0 && nameLen <= 128 && received >= 20 + nameLen) {
            stats.name = CleanPresenceText(std::string(response + 20, response + 20 + nameLen), SERVER_NAME_LABEL);
        }
    }

    return true;
}

// ─── Discord Callbacks ────────────────────────────────────────────────────────
static void OnDiscordReady(const DiscordUser* user) {
    // Called when Discord connects
}

static void OnDiscordDisconnected(int errCode, const char* message) {
    // Called when Discord disconnects
}

static void OnDiscordError(int errCode, const char* message) {
    // Called on error
}

static void OnDiscordJoin(const char* secret) {
    // Optional: Handle join requests
}
// ─────────────────────────────────────────────────────────────────────────────

static void UpdatePresence() {
    DiscordRichPresence presence = {};

    // State line (2nd line, smaller)
    std::string state;
    // Details line (1st line, larger)
    std::string details;

    if (!SAMP::IsLoaded()) {
        details = SERVER_NAME_LABEL;
        state   = SERVER_SUBTITLE;
    } else if (!SAMP::IsInServer()) {
        details = SERVER_NAME_LABEL;
        state   = "Browsing servers";
    } else {
        std::string serverAddress = GetBestServerAddress();
        ServerStats stats = {0, DEFAULT_MAX_PLAYERS, ""};
        if (!QuerySampServerStats(serverAddress, stats)) {
            stats.maxPlayers = ClampMaxPlayers(SAMP::GetMaxPlayers());
            stats.players = ClampPlayersCount(SAMP::GetPlayersCount(), stats.maxPlayers);
            stats.name = CleanPresenceText(SAMP::GetServerName(), "");
        }

        std::string serverName = stats.name.empty() ? SERVER_NAME_LABEL : stats.name;
        details = SERVER_NAME_LABEL;

        std::ostringstream ss;
        ss << serverName << " | " << serverAddress << " (" << stats.players << "/" << stats.maxPlayers << ")";
        state = ss.str();
    }

    presence.details        = details.c_str();
    presence.state          = state.c_str();
    presence.startTimestamp = g_startTimestamp;
    presence.largeImageKey  = LARGE_IMAGE_KEY;
    presence.largeImageText = LARGE_IMAGE_TEXT;
    presence.smallImageKey  = SMALL_IMAGE_KEY;
    presence.smallImageText = SMALL_IMAGE_TEXT;

    Discord_UpdatePresence(&presence);
}

static void PresenceThread() {
    // Wait for GTA to fully load before initializing
    Sleep(5000);

    WSADATA wsaData = {};
    g_winsockReady = WSAStartup(0x0202, &wsaData) == 0;

    DiscordEventHandlers handlers = {};
    handlers.ready        = OnDiscordReady;
    handlers.disconnected = OnDiscordDisconnected;
    handlers.errored      = OnDiscordError;
    handlers.joinGame     = OnDiscordJoin;

    Discord_Initialize(DISCORD_APP_ID, &handlers, 1, nullptr);

    g_startTimestamp = (int64_t)time(nullptr);

    while (g_running.load()) {
        UpdatePresence();
        Discord_RunCallbacks();
        Sleep(UPDATE_INTERVAL_MS);
    }

    Discord_ClearPresence();
    Discord_Shutdown();
    if (g_winsockReady) {
        WSACleanup();
        g_winsockReady = false;
    }
}

// ─── DLL Entry Point ─────────────────────────────────────────────────────────
BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD reason, LPVOID reserved) {
    switch (reason) {
        case DLL_PROCESS_ATTACH:
            DisableThreadLibraryCalls(hInstance);
            g_running = true;
            {
                std::thread(PresenceThread).detach();
            }
            break;

        case DLL_PROCESS_DETACH:
            g_running = false;
            Sleep(200); // let thread clean up
            break;
    }
    return TRUE;
}
