# VORTEX ROLE PLAY — Discord Rich Presence ASI Plugin

Shows **VORTEX ROLE PLAY** server info on Discord while playing SA-MP.

![VORTEX ROLE PLAY Logo](vortex_logo.png)

---

## What it shows on Discord

| Field | Content |
|-------|---------|
| **Details** | Server name (VORTEX ROLE PLAY) |
| **State** | Your character name + score |
| **Large image** | VORTEX ROLE PLAY logo |
| **Small image** | SA-MP icon (optional) |
| **Party size** | Players online / max players |
| **Elapsed time** | Time since you launched GTA |

---

## Step 1 — Create your Discord Application

1. Go to https://discord.com/developers/applications
2. Click **New Application** → name it **VORTEX ROLE PLAY**
3. Copy the **Application ID** (you'll need it below)
4. Go to **Rich Presence** → **Art Assets**
5. Upload `vortex_logo.png` as the **Large Image**
6. Set the key name to `vortex_logo`
7. Optionally upload a small SA-MP icon with key `samp_icon`

---

## Step 2 — Configure the plugin

Open `src/main.cpp` and edit these lines at the top:

```cpp
static const char* DISCORD_APP_ID = "YOUR_DISCORD_APP_ID_HERE";  // ← paste your App ID
static const char* SERVER_IP      = "vxrplaunchsoon:7777";  // VORTEX server address
```

---

## Step 3 — Download dependencies

Download the **discord-rpc** prebuilt library (Windows 32-bit):
- https://github.com/discord/discord-rpc/releases
- Download `discord-rpc-win.zip`
- Extract and copy:
  - `win32-static/lib/discord-rpc.lib` → `lib/discord-rpc.lib` (Create the `lib` folder if it doesn't exist)
  - `win32-static/discord_rpc.h` is already in `include/` (provided)

---

## Step 4 — Build (Windows, 32-bit)

### Requirements
- Visual Studio 2019 or 2022 (with C++ Desktop workload)
- CMake 3.16+

### How to Build

1. Open the **x86 Native Tools Command Prompt for VS 2022**. *(Crucial: Must be the x86 version)*
2. Navigate to your folder: `cd "C:\Users\Biravin A\Downloads\historic-rpc-plugin\historic-rpc-plugin"`
3. Run the script: `compile.bat`

This produces `build/Release/HistoricRPC.asi`

---

## Step 5 — Install

1. Copy `HistoricRPC.asi` to your **GTA San Andreas** folder (where `gta_sa.exe` is)
2. Make sure you have **ASI Loader** installed — get it from:
   https://www.gtagarage.com/mods/show.php?id=21709
   (or use CLEO which includes it)
3. Copy `discord-rpc.dll` from the discord-rpc zip next to `gta_sa.exe`
4. Launch GTA San Andreas and connect to VORTEX ROLE PLAY
5. Open Discord — your presence will appear within ~5 seconds

---

## File structure

```
historic-rpc-plugin/
├── src/
│   └── main.cpp              ← Main plugin source
├── include/
│   ├── discord_rpc.h         ← Discord RPC header
│   └── samp_memory.h         ← SA-MP memory reader (0.3.7 R1/R2/R3)
├── lib/
│   └── discord-rpc.lib       ← Download & place here (see Step 3)
├── CMakeLists.txt            ← Build configuration
├── vortex_logo.png         ← Upload this to Discord Dev Portal
└── README.md
```

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| Nothing shows on Discord | Make sure Discord is running before GTA SA |
| Wrong App ID error | Double-check you pasted the correct Application ID |
| Plugin doesn't load | Make sure ASI Loader is installed |
| Build fails with missing lib | Download discord-rpc.lib and place in `lib/` folder |
| Shows "Unknown" player name | Your SA-MP version may differ — R1/R2/R3 all supported |

---

## SA-MP Version Support

| Version | Status |
|---------|--------|
| SA-MP 0.3.7 R1 | Supported |
| SA-MP 0.3.7 R2 | Supported |
| SA-MP 0.3.7 R3-1 | Supported |
| SA-MP 0.3DL | Not supported |

---

Made for **VORTEX ROLE PLAY** — enjoy your server!


## VORTEX configuration notes

- The player name is read automatically from the SA-MP client when supported.
- Server address is configured as `vxrplaunchsoon:7777`. This must resolve to a real hostname/IP for the server to be queried; if `vxrplaunchsoon` is only a temporary placeholder, replace it with the actual domain or IP before launch.
- Create your own Discord application for VORTEX ROLE PLAY and replace `YOUR_VORTEX_DISCORD_APPLICATION_ID` in `src/main.cpp` with its Application ID.
- In the Discord Developer Portal, upload the VORTEX logo as a Rich Presence art asset with the key `vortex_logo`.
- This legacy discord-rpc header does not support custom presence buttons. The Discord invite is shown in the image hover text, but clickable “Join Server / Discord Server” buttons require a newer integration/SDK and additional implementation.
- This archive contains the customized source; the included prebuilt `HistoricRPC.asi` has not been rebuilt and still contains the old settings. Rebuild with the instructions above before using the customized version.
