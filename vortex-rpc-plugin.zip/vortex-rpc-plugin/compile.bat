@echo off
REM Direct compilation using MSVC compiler
REM This script compiles the Historic RPC plugin using environment variables set by vcvarsall.bat

setlocal enabledelayedexpansion

REM Set up paths
set "PROJECT_DIR=%~dp0"
set "OUTPUT_DIR=%PROJECT_DIR%build\Release"
set "LIB_DIR=%PROJECT_DIR%lib"
set "INCLUDE_DIR=%PROJECT_DIR%include"

REM Create output directory
if not exist "%OUTPUT_DIR%" mkdir "%OUTPUT_DIR%"
if exist "%OUTPUT_DIR%\HistoricRPC.asi" del /f /q "%OUTPUT_DIR%\HistoricRPC.asi"
if exist "%OUTPUT_DIR%\HistoricRPC.dll" del /f /q "%OUTPUT_DIR%\HistoricRPC.dll"

REM Check for compiler
where cl.exe >nul 2>nul
if errorlevel 1 (
    echo Error: cl.exe not found. Please run this script from a Visual Studio x86 Developer Command Prompt.
    exit /b 1
)

REM Check if we are in an x86 environment
if "%VSCMD_ARG_TGT_ARCH%" neq "x86" (
    echo Error: This plugin must be compiled for x86 32-bit.
    echo Please use the "x86 Native Tools Command Prompt" instead.
    exit /b 1
)

REM Check if discord-rpc.lib exists
if not exist "%LIB_DIR%\discord-rpc.lib" (
    echo Error: discord-rpc.lib not found in %LIB_DIR%
    exit /b 1
)

REM Compile main.cpp - use system include paths from environment
echo Compiling main.cpp...
cl.exe /W4 /MD /O2 /D"WIN32" /D"_WINDOWS" /D"_USRDLL" /I"%INCLUDE_DIR%" /Fo"%OUTPUT_DIR%\main.obj" /c "%PROJECT_DIR%\src\main.cpp"

if errorlevel 1 (
    echo Compilation failed!
    exit /b 1
)

REM Link to create DLL
echo Linking...
link.exe /DLL /OUT:"%OUTPUT_DIR%\HistoricRPC.dll" /SUBSYSTEM:WINDOWS "%OUTPUT_DIR%\main.obj" "%LIB_DIR%\discord-rpc.lib" user32.lib kernel32.lib advapi32.lib ws2_32.lib legacy_stdio_definitions.lib

if errorlevel 1 (
    echo Linking failed!
    exit /b 1
)

REM Rename DLL to ASI
if exist "%OUTPUT_DIR%\HistoricRPC.dll" (
    if exist "%OUTPUT_DIR%\HistoricRPC.asi" del /f /q "%OUTPUT_DIR%\HistoricRPC.asi"
    move /Y "%OUTPUT_DIR%\HistoricRPC.dll" "%OUTPUT_DIR%\HistoricRPC.asi" >nul
    copy /Y "%OUTPUT_DIR%\HistoricRPC.asi" "%PROJECT_DIR%\HistoricRPC.asi" >nul
    echo.
    echo Build successful!
    echo ASI plugin created at: %OUTPUT_DIR%\HistoricRPC.asi
    echo Root ASI updated at: %PROJECT_DIR%\HistoricRPC.asi
    dir "%OUTPUT_DIR%\HistoricRPC.asi"
) else (
    echo Error: Failed to create DLL
    exit /b 1
)

endlocal
